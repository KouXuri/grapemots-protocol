#!/usr/bin/env bash
# Per-frame tracks of the batch-8 retrain of crop checkpoint PathPlanning_4_s2 (ledger 10.28.17, R rule:
# median |delta e| 0.339 >= 0.30, so the batch-8 checkpoint replaces the published one). Same replay as the
# queue's replay-config (main-grid tracker cfg/trackers/botsort_gmc.yaml), with --keep for the per-frame records.
# The published checkpoint's replay at 3072 reproduces its archived live arms identity for identity (checked 11-27).
set -u
cd /home/kou/my_env/yolo26
OUT=runs/pa_followup_1124/r/records
mkdir -p "$OUT"
run() {
  s=$1
  nice -n 19 .venv/bin/python tools/error_sources_1120.py replay-config \
    --dets runs/pa_followup_1124/r/dets/r_s2__PathPlanning_4_s${s}.json --cfg cfg/trackers/botsort_gmc.yaml \
    --keep --out "$OUT" --tag r_s2__PathPlanning_4_s${s} > "$OUT/log_s${s}.txt" 2>&1
  echo "s${s} rc=$?" >> "$OUT/done.txt"
}
run 1536 & run 2048 & wait
run 2560 & run 3072 & wait
run 3840
echo all >> "$OUT/done.txt"
